package com.Dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Category;
import com.Entity.Product;
import com.Entity.ProductInfo;


@Repository
public class ProductDao {
@Autowired
SessionFactory sf;

	public List<Product> getaAllProducts() {
		Session session=sf.openSession();
		Criteria criteria=session.createCriteria(Product.class);
		List<Product>list=criteria.list();
		return list;
	}
	
	public Product viewproduct(int pid ) {
		Session session=sf.openSession();
		Product product =session.get(Product.class, pid);
		return product;
	}
	
	
	
	public List<ProductInfo> getAllProductsWithcategory(int pid) {
		Session session=sf.openSession();
		Query query=session.createSQLQuery("select product.pid,product.pname,product.price,category.cid,category.name  from product join category on product.pid=category.cid and pid=" +pid);
		List<Object[]> list=query.list();
		List<ProductInfo>arrayList =new ArrayList<ProductInfo>();
		
		for( Object[] array :list) 
		{
			arrayList.add(new ProductInfo((int) array[0],(String) array[1],(int )array[2],(int)array[3],(String) array[4]));
		}
		return arrayList;
		
	}
	
	public Product deleteProduct(int pid) {
		Session session =sf.openSession();
		Product product =session.get(Product.class, pid);
		Transaction tr =session.beginTransaction();
		session.delete(product);
		tr.commit();
		
		return product;
	}
	
	public Product addProduct (Product product  , int cid ) 
	{
		System.out.println("Category id is "+cid);
		
		Session session =sf.openSession();
		Category category =session.load(Category.class, cid);
		System.out.println("Product from given category are :- "+category.getProducts());
		List<Product >productlist=category.getProducts();
		
		Transaction tr =session.beginTransaction();
		productlist.add(product);
		tr.commit();
		System.out.println("product added into database..");
		return product;
	}

	
	
	
	
	
}
