package com.Controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Category;
import com.Entity.Product;
import com.Service.ProductService;

@RestController
@RequestMapping("productApi")
public class ProductController {
@Autowired
SessionFactory sf;


@PostMapping("addProduct/{cid}")  
public Product addProduct(@RequestBody Product product, @PathVariable int cid) {
		System.out.println("Category id is "+cid);
		Session session=sf.openSession();
		Category category =session.load(Category.class,cid);
		System.out.println("Products from given category are :- "+category.getProducts());
		
		/*get list of product and add product int it*/
		
		List<Product>productlist=category.getProducts();
		Transaction tr =session.beginTransaction();
		productlist.add(product);
		tr.commit();
		System.out.println("product added into database");
		
		return product;
	
	}
@PutMapping("updateProduct")
public Product updateProduct(@RequestBody Product clientProduct) {
	     Session session=sf.openSession();
	     Transaction tr =session.beginTransaction();
	     session.update(clientProduct);
	     tr.commit();
	     return clientProduct;
	
}

}
