package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Dao.ProductDao;
import com.Entity.Product;
import com.Entity.ProductInfo;

@Service
public class ProductService {
@Autowired
ProductDao pd;

public List<Product> getAllProducts() {
	return pd.getaAllProducts();
	
}
public Product viewproduct(int pid) {
	return pd.viewproduct(pid);
}

public List<ProductInfo> getAllProductsWithcategory(int pid) {
	return pd.getAllProductsWithcategory(pid);
}

public Product deleteProduct(int pid) {
	return pd.deleteProduct(pid);
	
}

public Product addProduct(Product product , int cid) {
	return pd.addProduct(product, cid);
}
}
