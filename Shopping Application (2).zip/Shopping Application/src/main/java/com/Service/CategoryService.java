package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.Dao.CategoryDao;
import com.Entity.Category;
@Service
public class CategoryService {
	@Autowired
	CategoryDao Dao;
	
	public Category saveCategory ( @RequestBody Category category) 
	{
		return Dao.saveCategory(category);
	}
	
	public Category getCategory(int cid)
    {
		return Dao.getCategory(cid);
    }

	public Category updateCategory(Category category) {
		
		return Dao.updateCategory(category);
	}

	public Category deleteCategory(int cid) {
		
		return Dao.deleteCategory(cid);
	}

	public List<Category> getAllCategory()
    {
			return Dao.getAllCategory();
    }
}
