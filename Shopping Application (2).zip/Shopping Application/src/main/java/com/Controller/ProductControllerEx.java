package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Product;
import com.Entity.ProductInfo;
import com.Service.ProductService;

@RestController
@RequestMapping("productapi")
public class ProductControllerEx {
@Autowired
ProductService ps;


@RequestMapping("getAllProducts")
public List<Product> getAllProducts() {
	return ps.getAllProducts();
}

@RequestMapping("viewproduct{pid}")
public Product viewproduct(@PathVariable int pid) {
	return ps.viewproduct(pid);
}

@RequestMapping("allProductsWithCategory/{pid}")
public List<ProductInfo> getAllProductsWithcategory(@PathVariable int pid) {
	return ps.getAllProductsWithcategory(pid);
}

@DeleteMapping("deleteProduct{pid}")
public Product deleteProduct(@PathVariable int pid) {
	return ps.deleteProduct(pid);
}

}
