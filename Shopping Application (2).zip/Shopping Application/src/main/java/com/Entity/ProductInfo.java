package com.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ProductInfo {
	@Id
	int pid;
	String pname;
	int price;
	int cid;
	String name;

	public ProductInfo() {
		super();
	}

	
	public ProductInfo(int pid, String pname, int price, int cid, String name) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.cid = cid;
		this.name = name;
	}


	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ProductInfo [pid=" + pid + ", pname=" + pname + ", price=" + price + ", cid=" + cid + ", name=" + name
				+ "]";
	}

}
