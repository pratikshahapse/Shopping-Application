package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Category;
import com.Entity.ObjectNotFoundException;
import com.Service.CategoryService;

@RestController
@RequestMapping("CategoryApi")
public class CategoryController {
	@Autowired
	CategoryService service ;
	 

	 @PostMapping("saveCategory")
		public Category saveCategory(@RequestBody Category category)
		{
	    	System.out.println(category);
	    	
	    	service.saveCategory(category);
	    	    	
			return category;
			
			// To create JSON String , Spring uses getter methods
			
		}
	    
	    @RequestMapping("getCategory/{cid}")
	    public Category getCategory(@PathVariable int cid)
	    {
	    	   Category category= service.getCategory(cid);
	    	   
	  if (category==null) 
	     {
	    		   throw new ObjectNotFoundException("No record found with cid "+cid) ;  
	     }
	    	   else {
	    		   return category;
	    	        }
	    	   
	    }

	    // {cid:2,name:"fashion"} is sent by client(javascript/postman)
	    
	    @PutMapping("updateCategory")
		public Category updateCategory(@RequestBody Category category)
	    {
	    	return service.updateCategory(category);
	    }
	   
	    @RequestMapping("deleteCategory/{cid}")
	    public Category deleteCategory(@PathVariable int cid)
	    {
	    	   return service.deleteCategory(cid);
	    }
	    
	    @RequestMapping("getAllCategory")
	    public List<Category> getAllCategory()
	    {
	    	return service.getAllCategory();
	    }  
}
