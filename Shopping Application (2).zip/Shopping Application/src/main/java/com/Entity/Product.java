package com.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author Pratiksha
 *
 */
@Entity
public class Product {
	@Id
	int pid;
	String pname;
	int price;
	String imagepath;
	transient MultipartFile images;
	
	public Product() {
		super();
	}
	

	




	public Product(int pid, String pname, int price, String imagepath, MultipartFile images) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.price = price;
		this.imagepath = imagepath;
		this.images = images;
	}

	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}


	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getImagepath() {
		return imagepath;
	}

	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}

	public MultipartFile getImages() {
		return images;
	}

	public void setImages(MultipartFile images) {
		this.images = images;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price + ", imagepath=" + imagepath
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	

	}
